﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class KeyPad : MonoBehaviour
{
    public bool Addition;
    public bool Subtraction;
    public bool Multiplication;
    public bool Division;
    public bool Modulus;

    public int m_FirstNumber;
    public int m_SecondNumber;
    public int m_Answer;
    public int m_PlayerAnswer;

    public Operator m_Operator;

    // Text
    Text Text_Left;
    Text Text_Right;
    Text Text_Operator;
    Text Text_Answer;
    Text Text_FirstNumber;
    Text Text_SecondNumber;

    public Canvas Canvas_KeyPad;
    public Canvas Canvas_Alt_KeyPad;

    // KeyPad Buttons
    public Button Key_1;
    public Button Key_2;
    public Button Key_3;
    public Button Key_4;
    public Button Key_5;
    public Button Key_6;
    public Button Key_7;
    public Button Key_8;
    public Button Key_9;
    public Button Key_0;
    public Button Key_Delete;
    public Button Key_Menu;

    // public bool[] m_Operations; // 1: Addition, 2: Subtraction, 3: Muliplecation, 4; Division

    public enum Operator
    {
        Addition,
        Subtraction,
        Multiplication,
        Division
    }

    // Member Vars
    public int m_ControlScheme;

    int m_NumberOfDigits;
    int m_NumberOfOperators;

    public GameManager m_GameManager;

    //EventSystem m_EventSystem = EventSystem.current;

    // Use this for initialization
    void Start()
    {
        m_ControlScheme = 0;
        m_Answer = 0;
        m_PlayerAnswer = 0;

        //m_EventSystem = EventSystem.current;

        Addition = true;
        Subtraction = false;
        Multiplication = false;
        Division = false;
        Modulus = false;

        Text_Answer = GameObject.Find("Answer Number").GetComponent<Text>();
        Text_FirstNumber = GameObject.Find("First Number").GetComponent<Text>();
        Text_SecondNumber = GameObject.Find("Second Number").GetComponent<Text>();
        Text_Operator = GameObject.Find("Operator").GetComponent<Text>();

        //GetKeyPadObjects();
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown("space"))
        {
            GenerateQuestion();
        }

        // If the player gets the answer right
        if(m_PlayerAnswer == m_Answer)
        {
            GenerateQuestion();
            Text_Answer.text = "";
        }
    }

    void GetKeyPadObjects()
    {
        //// Remove Listeners first
        //Key_1.onClick.RemoveListener(() => ButtonClicked(1));
        //Key_2.onClick.RemoveListener(() => ButtonClicked(2));
        //Key_3.onClick.RemoveListener(() => ButtonClicked(3));
        //Key_4.onClick.RemoveListener(() => ButtonClicked(4));
        //Key_5.onClick.RemoveListener(() => ButtonClicked(5));
        //Key_6.onClick.RemoveListener(() => ButtonClicked(6));
        //Key_7.onClick.RemoveListener(() => ButtonClicked(7));
        //Key_8.onClick.RemoveListener(() => ButtonClicked(8));
        //Key_9.onClick.RemoveListener(() => ButtonClicked(9));
        //Key_0.onClick.RemoveListener(() => ButtonClicked(0));
        //Key_Delete.onClick.RemoveListener(() => ButtonClicked(11));
        //Key_Menu.onClick.RemoveListener(() => ButtonClicked(12));

        Canvas_KeyPad.enabled = false;
        Canvas_Alt_KeyPad.enabled = false;

        if (m_ControlScheme == 0)
        {
            Canvas_KeyPad.enabled = true;

            Key_1 = GameObject.Find("Button 1").GetComponent<Button>();
            Key_2 = GameObject.Find("Button 2").GetComponent<Button>();
            Key_3 = GameObject.Find("Button 3").GetComponent<Button>();
            Key_4 = GameObject.Find("Button 4").GetComponent<Button>();
            Key_5 = GameObject.Find("Button 5").GetComponent<Button>();
            Key_6 = GameObject.Find("Button 6").GetComponent<Button>();
            Key_7 = GameObject.Find("Button 7").GetComponent<Button>();
            Key_8 = GameObject.Find("Button 8").GetComponent<Button>();
            Key_9 = GameObject.Find("Button 9").GetComponent<Button>();
            Key_0 = GameObject.Find("Button 0").GetComponent<Button>();
            Key_Delete = GameObject.Find("Button X").GetComponent<Button>();
            Key_Menu = GameObject.Find("Button M").GetComponent<Button>();          

            Key_1.onClick.AddListener(() => ButtonClicked(1));
            Key_2.onClick.AddListener(() => ButtonClicked(2));
            Key_3.onClick.AddListener(() => ButtonClicked(3));
            Key_4.onClick.AddListener(() => ButtonClicked(4));
            Key_5.onClick.AddListener(() => ButtonClicked(5));
            Key_6.onClick.AddListener(() => ButtonClicked(6));
            Key_7.onClick.AddListener(() => ButtonClicked(7));
            Key_8.onClick.AddListener(() => ButtonClicked(8));
            Key_9.onClick.AddListener(() => ButtonClicked(9));
            Key_0.onClick.AddListener(() => ButtonClicked(0));
            Key_Delete.onClick.AddListener(() => ButtonClicked(11));
            Key_Menu.onClick.AddListener(() => ButtonClicked(12));
        }

        if(m_ControlScheme == 1)
        {
            Canvas_Alt_KeyPad.enabled = true;

            Key_1 = GameObject.Find("bButton 1").GetComponent<Button>();
            Key_2 = GameObject.Find("bButton 2").GetComponent<Button>();
            Key_3 = GameObject.Find("bButton 3").GetComponent<Button>();
            Key_4 = GameObject.Find("bButton 4").GetComponent<Button>();
            Key_5 = GameObject.Find("bButton 5").GetComponent<Button>();
            Key_6 = GameObject.Find("bButton 6").GetComponent<Button>();
            Key_7 = GameObject.Find("bButton 7").GetComponent<Button>();
            Key_8 = GameObject.Find("bButton 8").GetComponent<Button>();
            Key_9 = GameObject.Find("bButton 9").GetComponent<Button>();
            Key_0 = GameObject.Find("bButton 0").GetComponent<Button>();
            Key_Delete = GameObject.Find("bButton X").GetComponent<Button>();
            Key_Menu = GameObject.Find("bButton M").GetComponent<Button>();

            Key_1.onClick.AddListener(() => ButtonClicked(1));
            Key_2.onClick.AddListener(() => ButtonClicked(2));
            Key_3.onClick.AddListener(() => ButtonClicked(3));
            Key_4.onClick.AddListener(() => ButtonClicked(4));
            Key_5.onClick.AddListener(() => ButtonClicked(5));
            Key_6.onClick.AddListener(() => ButtonClicked(6));
            Key_7.onClick.AddListener(() => ButtonClicked(7));
            Key_8.onClick.AddListener(() => ButtonClicked(8));
            Key_9.onClick.AddListener(() => ButtonClicked(9));
            Key_0.onClick.AddListener(() => ButtonClicked(0));
            Key_Delete.onClick.AddListener(() => ButtonClicked(11));
            Key_Menu.onClick.AddListener(() => ButtonClicked(12));
        }    
    }


    public void ButtonClicked(int ButtonNum)
    {
        if (ButtonNum >= 0 && ButtonNum <= 9)
        {
            Text_Answer.text = Text_Answer.text.ToString() + ButtonNum;
            m_PlayerAnswer = int.Parse(Text_Answer.text);
        }

        if (ButtonNum == 11)
        {
            Text_Answer.text = "";
            m_PlayerAnswer = 0;
        }

        if (ButtonNum == 12)
        {
            m_GameManager.GoToScreen_Options();
        }

    }

    public void SetNumberOfDigits(int num)
    {
        m_NumberOfDigits = num;
    }

    public void SetOperators(bool add, bool sub, bool multi, bool div)
    {
        Addition = add;
        Subtraction = sub;
        Multiplication = multi;
        Division = div;

        // Sets the number of operators for the game
        m_NumberOfOperators = 0;

        if (Addition == true)
            m_NumberOfOperators++;
        if (Subtraction == true)
            m_NumberOfOperators++;
        if (Multiplication == true)
            m_NumberOfOperators++;
        if (Division == true)
            m_NumberOfOperators++;

        GenerateQuestion();
    }

    public void SetControlScheme(int Scheme)
    {
        m_ControlScheme = Scheme;

        GetKeyPadObjects();
    }

    void GenerateQuestion()
    {
        // Determine which operation will be asked      /// FIND A BETTER WAY THIS IS HORRIBLE

        // Ghetto while loop
        for(int i = 0; i < 100; i++)
        {
            int ran = Random.Range(0, 4);

            if (ran == 0)
            {
                if(Addition == true)
                {
                    m_Operator = Operator.Addition;
                    i = 400;
                }
            }
            else if (ran == 1)
            {
                if (Subtraction == true)
                {
                    m_Operator = Operator.Subtraction;
                    i = 400;
                }
            }
            else if (ran == 2)
            {
                if (Multiplication == true)
                {
                    m_Operator = Operator.Multiplication;
                    i = 400;
                }
            }
            else if (ran == 3)
            {
                if (Division == true)
                {
                    m_Operator = Operator.Division;
                    i = 400;
                }
            }
        } 


        // Determine the digits in the question

        // Get the even numbers
        if(m_NumberOfDigits % 2 == 0)
        {       
            int ran = Random.Range(0, 10 * (m_NumberOfDigits /2));
            m_FirstNumber = ran;
            ran = Random.Range(0, 10 * (m_NumberOfDigits / 2));
            m_SecondNumber = ran;
        }
        else
        {
            int ran = Random.Range(0, 10 * ((m_NumberOfDigits - 1) / 2));
            m_FirstNumber = ran;
            ran = Random.Range(0, 10 * (((m_NumberOfDigits - 1) / 2) + 1));
            m_SecondNumber = ran;
        }

        // Calculate the awnser
        if(m_Operator == Operator.Addition)
        {
            m_Answer = m_FirstNumber + m_SecondNumber;
            Text_Operator.text = "+";
        }
        else if(m_Operator == Operator.Subtraction)
        {
            m_Answer = m_FirstNumber - m_SecondNumber;
            Text_Operator.text = "-";
        }
        else if (m_Operator == Operator.Multiplication)
        {
            m_Answer = m_FirstNumber * m_SecondNumber;
            Text_Operator.text = "X";
        }
        else if (m_Operator == Operator.Division)
        {
            m_Answer = m_FirstNumber / m_SecondNumber;
            Text_Operator.text = "/";
        }

        // Set the text
        Text_FirstNumber.text =  m_FirstNumber.ToString();
        Text_SecondNumber.text = m_SecondNumber.ToString();
    }

    public void ToggleCanvases(bool toggle)
    {
        if(toggle == true)
        {

        }
       
    }
}
