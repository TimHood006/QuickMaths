﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class GameMenu : MonoBehaviour {

    Button Button_DigitUp;
    Button Button_DigitDown;


    Button Button_Control_Up;
    Button Button_Control_Down;

    Button Button_Addition;
    Button Button_Subtraction;
    Button Button_Multiplecation;
    Button Button_Division;

    public Text Text_NumDigits;
    public Text Text_ControlScheme;
   

    public int m_NumberOfDigits;
    public int m_ControlScheme;

    public bool m_Addition;
    public bool m_Subtraction;
    public bool m_Multiplication;
    public bool m_Division;
    public bool m_Modulus;


    // Use this for initialization
    void Start ()
    {
        SetupObjects();

        m_NumberOfDigits = 2;
        m_ControlScheme = 0;

    m_Addition = true;
    m_Subtraction = false;
    m_Multiplication = false;
    m_Division = false;
    m_Modulus = false;

    Text_NumDigits.text = m_NumberOfDigits.ToString();
    }
	
	// Update is called once per frame
	void Update ()
    {
        if(m_Addition == true)
        {
            Button_Addition.GetComponent<Image>().color = new Color32(225, 170, 107, 100);
        }
         else
        {
            Button_Addition.GetComponent<Image>().color = new Color32(225, 225, 225, 100);
        }

        if (m_Subtraction == true)
        {
            Button_Subtraction.GetComponent<Image>().color = new Color32(225, 170, 107, 100);
        }
         else
        {
            Button_Subtraction.GetComponent<Image>().color = new Color32(225, 225, 225, 100);
        }

        if (m_Multiplication == true)
        {
            Button_Multiplecation.GetComponent<Image>().color = new Color32(225, 170, 107, 100);
        }
         else
        {
            Button_Multiplecation.GetComponent<Image>().color = new Color32(225, 225, 225, 100);
        }

        if (m_Division == true)
        {
            Button_Division.GetComponent<Image>().color = new Color32(225, 170, 107, 100);
        }
         else
        {
            Button_Division.GetComponent<Image>().color = new Color32(225, 225, 225, 100);
        }

        // For controls
        if (m_ControlScheme > 1)
            m_ControlScheme = 0;
        if (m_ControlScheme < 0)
            m_ControlScheme = 1;

        if (m_ControlScheme == 0)
        {
            Text_ControlScheme.text = "KeyPad";
        }
        if (m_ControlScheme == 1)
        {
            Text_ControlScheme.text = "Quick Math";
        }

    }

    void SetupObjects()
    {
        Button_DigitUp = GameObject.Find("Digit Up").GetComponent<Button>();
        Button_DigitDown = GameObject.Find("Digit Down").GetComponent<Button>();

        Button_Control_Up = GameObject.Find("Control Scheme Up").GetComponent<Button>();
        Button_Control_Down = GameObject.Find("Control Scheme Down").GetComponent<Button>();

        Button_Addition = GameObject.Find("Operator +").GetComponent<Button>();
        Button_Subtraction = GameObject.Find("Operator -").GetComponent<Button>();
        Button_Multiplecation = GameObject.Find("Operator X").GetComponent<Button>();
        Button_Division = GameObject.Find("Operator /").GetComponent<Button>();

        Button_DigitUp.onClick.AddListener(() => ButtonClicked(0));
        Button_DigitDown.onClick.AddListener(() => ButtonClicked(1));

        Button_Addition.onClick.AddListener(() => ButtonClicked(2));
        Button_Subtraction.onClick.AddListener(() => ButtonClicked(3));
        Button_Multiplecation.onClick.AddListener(() => ButtonClicked(4));
        Button_Division.onClick.AddListener(() => ButtonClicked(5));

        Button_Control_Up.onClick.AddListener(() => ButtonClicked(6));
        Button_Control_Down.onClick.AddListener(() => ButtonClicked(7));


        Text_NumDigits = GameObject.Find("Digits Number").GetComponent<Text>();
        Text_ControlScheme = GameObject.Find("Control Scheme Text").GetComponent<Text>();
    }

    void ButtonClicked(int ButtonNum)
    {
        if (ButtonNum == 0)
        {
            m_NumberOfDigits++;
            Text_NumDigits.text = m_NumberOfDigits.ToString();
        }
        else if (ButtonNum == 1)
        {
            m_NumberOfDigits--;
            Text_NumDigits.text = m_NumberOfDigits.ToString();
        }
        else if (ButtonNum == 2)
        {
            if (m_Addition == true)
                m_Addition = false;
            else
                m_Addition = true;
        }
        else if (ButtonNum == 3)
        {
            if (m_Subtraction == true)
                m_Subtraction = false;
            else
                m_Subtraction = true;
        }
        else if (ButtonNum == 4)
        {
            if (m_Multiplication == true)
                m_Multiplication = false;
            else
                m_Multiplication = true;
        }
        else if (ButtonNum == 5)
        {
            if (m_Division == true)
                m_Division = false;
            else
                m_Division = true;
        }
        else if (ButtonNum == 6)
        {
            m_ControlScheme++;
        }
        else if (ButtonNum == 7)
        {
            m_ControlScheme--;
        }
    }


    public int GetNumberOfDigits()
    {
        return m_NumberOfDigits;
    }

    public bool GetOperatorAddition()
    {
        return m_Addition;
    }
    public bool GetOperatorSubttraction()
    {
        return m_Subtraction;
    }
    public bool GetOperatorMultiplication()
    {
        return m_Multiplication;
    }
    public bool GetOperatorDivision()
    {
        return m_Division;
    }
    public int GetControlScheme()
    {
        return m_ControlScheme;
    }
}
