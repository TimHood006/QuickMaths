﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class InfoPopup : MonoBehaviour
{
    public GameObject m_PopUp;

    public Button m_Button;

    public EventTrigger m_EventTrigger;

    public Text Text_Title;
    public Text Text_Description;

    bool m_IsOpen;

    string m_Title;
    string m_Description;

    void Start()
    {
        m_IsOpen = false;

        InfoLibary InfoLab = new InfoLibary();

        m_Title = InfoLab.ReturnTitle(this.name);
        m_Description = InfoLab.ReturnDescription(this.name);

        Text_Title.text = m_Title;
        Text_Description.text = m_Description;
    }

    // Update is called once per frame
    void Update()
    {
        if (m_IsOpen == true)
        {
            m_PopUp.SetActive(true);
        }
        else if (m_IsOpen == false)
        {
            m_PopUp.SetActive(false);
        }

        if (m_IsOpen == true)
        {
            // For Mobile
            //if (Input.touchCount == 0)
            //{
            //    m_IsOpen = false;
            //}
        }
    }

    public void OnEnter()
    {
        m_IsOpen = true;
    }
    public void OnExit()
    {
        m_IsOpen = false;
    }

}
