﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InfoLibary
{
  
    public string ReturnTitle(string name)
    {
        if (name.Equals("InfoNumberOfDigits"))
        {
            return "Number Of Digits";
        }
        else if (name.Equals("InfoOperators"))
        {
            return "Operators";
        }
        else if (name.Equals("InfoTimeAttack"))
        {
            return "TimeAttack";
        }
        else if (name.Equals("InfoAdAttack"))
        {
            return "Ad Attack";
        }
        else
        {
            return " ";
        }
    }

    public string ReturnDescription(string des)
    {
        if (des.Equals("InfoNumberOfDigits"))
        {
            return "The total number of digits the question will be composed of.";
        }
        else if (des.Equals("InfoOperators"))
        {
            return "Select which kind of questions you will be asked";
        }
        else if (des.Equals("InfoTimeAttack"))
        {
            return "Enables a timer what will fail you if you dont select a question in time.";
        }
        else if (des.Equals("InfoAdAttack"))
        {
            return "Enables a penalty that will play an ad upon failure.";
        }
        else
        {
            return " ";
        }
    }
}
