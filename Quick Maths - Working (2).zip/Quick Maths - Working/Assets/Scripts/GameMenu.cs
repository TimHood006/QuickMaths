﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class GameMenu : MonoBehaviour {

    Button Button_DigitUp;
    Button Button_DigitDown;


    Button Button_Control_Up;
    Button Button_Control_Down;

    Button Button_Addition;
    Button Button_Subtraction;
    Button Button_Multiplecation;
    Button Button_Division;

    Button Button_TimeAttack;
    Button Button_AdAttack;

    public Slider Slider_Time;

    public Text Text_NumDigits;
    public Text Text_ControlScheme;
    public Text Text_Questions_Answered;
    public Text Text_Questions_Correct;
    public Text Text_Questions_InCorrect;
    public Text Text_Time;

    public RawImage RImage_Image1;
    public RawImage RImage_Image2;
   
    public int m_NumberOfDigits;
    public int m_ControlScheme;
    public float m_TimeSelected;

    public bool m_Addition;
    public bool m_Subtraction;
    public bool m_Multiplication;
    public bool m_Division;
    public bool m_Modulus;
    public bool m_TimeAttack;
    public bool m_AdAttack;

    public GameManager m_GameManager;

    private Vector3 fp;   //First touch position
    private Vector3 lp;   //Last touch position
    private float m_DragDistance;  //minimum distance for a swipe to be registered      


    // Use this for initialization
    void Start ()
    {
        SetupObjects();

        m_NumberOfDigits = 2;
        m_ControlScheme = 0;

        m_TimeSelected = 0.0f;
        m_TimeAttack = false;
        Text_Time.text = "Off";

        m_DragDistance = Screen.height * 15 / 100; //dragDistance is 15% height of the screen

        m_Addition = true;
        m_Subtraction = false;
        m_Multiplication = false;
        m_Division = false;
        m_Modulus = false;
        m_AdAttack = false;

    Text_NumDigits.text = m_NumberOfDigits.ToString();
    }
	
	// Update is called once per frame
	void Update ()
    {
        // Move From Update
        Text_Questions_Answered.text = (m_GameManager.m_PlayerData.Num_Of_Questions_Answered).ToString();

        if(m_Addition == true)
        {
            Button_Addition.GetComponent<Image>().color = new Color32(225, 170, 107, 100);
        }
         else
        {
            Button_Addition.GetComponent<Image>().color = new Color32(225, 225, 225, 100);
        }

        if (m_Subtraction == true)
        {
            Button_Subtraction.GetComponent<Image>().color = new Color32(225, 170, 107, 100);
        }
         else
        {
            Button_Subtraction.GetComponent<Image>().color = new Color32(225, 225, 225, 100);
        }

        if (m_Multiplication == true)
        {
            Button_Multiplecation.GetComponent<Image>().color = new Color32(225, 170, 107, 100);
        }
         else
        {
            Button_Multiplecation.GetComponent<Image>().color = new Color32(225, 225, 225, 100);
        }

        if (m_Division == true)
        {
            Button_Division.GetComponent<Image>().color = new Color32(225, 170, 107, 100);
        }
         else
        {
            Button_Division.GetComponent<Image>().color = new Color32(225, 225, 225, 100);
        }

        //if (m_TimeAttack == true)
        //{
        //    Button_TimeAttack.GetComponent<Image>().color = new Color32(225, 170, 107, 100);
        //}
        //else
        //{
        //    Button_TimeAttack.GetComponent<Image>().color = new Color32(225, 225, 225, 100);
        //}

        if (m_AdAttack == true)
        {
            Button_AdAttack.GetComponent<Image>().color = new Color32(225, 170, 107, 100);
        }
        else
        {
            Button_AdAttack.GetComponent<Image>().color = new Color32(225, 225, 225, 100);
        }

        // For controls
        if (m_ControlScheme > 1)
            m_ControlScheme = 0;
        if (m_ControlScheme < 0)
            m_ControlScheme = 1;

        if (m_ControlScheme == 0)
        {
            Text_ControlScheme.text = "KeyPad";
            RImage_Image1.enabled = true;
            RImage_Image2.enabled = false;
        }
        if (m_ControlScheme == 1)
        {
            Text_ControlScheme.text = "Quick Math";
            RImage_Image1.enabled = false;
            RImage_Image2.enabled = true;
        }
    }
    
    public bool GetAdAttack()
    {
        return m_AdAttack;
    }
    public float GetTime()
    {
        m_TimeSelected = Slider_Time.value;

        if (m_TimeSelected == 0)
            m_TimeSelected = 0;
        else if (m_TimeSelected == 1)
            m_TimeSelected = 3;
        else if (m_TimeSelected == 2)
            m_TimeSelected = 5;
        else if (m_TimeSelected == 3)
            m_TimeSelected = 10;
        else if (m_TimeSelected == 4)
            m_TimeSelected = 15;
        else if (m_TimeSelected == 5)
            m_TimeSelected = 30;
        else if (m_TimeSelected == 6)
            m_TimeSelected = 60;

        return m_TimeSelected;
    }


    void SetupObjects()
    {
        Button_DigitUp = GameObject.Find("Digit Up").GetComponent<Button>();
        Button_DigitDown = GameObject.Find("Digit Down").GetComponent<Button>();

        Button_Control_Up = GameObject.Find("Control Scheme Up").GetComponent<Button>();
        Button_Control_Down = GameObject.Find("Control Scheme Down").GetComponent<Button>();       

        Button_Addition = GameObject.Find("Operator +").GetComponent<Button>();
        Button_Subtraction = GameObject.Find("Operator -").GetComponent<Button>();
        Button_Multiplecation = GameObject.Find("Operator X").GetComponent<Button>();
        Button_Division = GameObject.Find("Operator /").GetComponent<Button>();

        //Button_TimeAttack = GameObject.Find("Time Attack Button").GetComponent<Button>();
        Button_AdAttack = GameObject.Find("Ad Attack Button").GetComponent<Button>();

        Button_DigitUp.onClick.AddListener(() => ButtonClicked(0));
        Button_DigitDown.onClick.AddListener(() => ButtonClicked(1));

        Button_Addition.onClick.AddListener(() => ButtonClicked(2));
        Button_Subtraction.onClick.AddListener(() => ButtonClicked(3));
        Button_Multiplecation.onClick.AddListener(() => ButtonClicked(4));
        Button_Division.onClick.AddListener(() => ButtonClicked(5));

        Button_Control_Up.onClick.AddListener(() => ButtonClicked(6));
        Button_Control_Down.onClick.AddListener(() => ButtonClicked(7));

       // Button_TimeAttack.onClick.AddListener(() => ButtonClicked(8));
        Button_AdAttack.onClick.AddListener(() => ButtonClicked(9));


        Text_NumDigits = GameObject.Find("Digits Number").GetComponent<Text>();
        Text_ControlScheme = GameObject.Find("Control Scheme Text").GetComponent<Text>();
        Text_Questions_Answered = GameObject.Find("Questions Answered").GetComponent<Text>();
        Text_Time = GameObject.Find("TimeText").GetComponent<Text>();

        Slider_Time = GameObject.Find("TimeSlider").GetComponent<Slider>();
    }

    public void SliderMoved()
    {
        if (Slider_Time.value == 0)
        {
            m_TimeSelected = 0.0f;
            Text_Time.text = "Off";
            m_TimeAttack = false;
        }
        else
        {
            m_TimeAttack = true;

            if (Slider_Time.value == 1)
            {
                m_TimeSelected = 3.0f;
                Text_Time.text = m_TimeSelected.ToString();
            }
            if (Slider_Time.value == 2)
            {
                m_TimeSelected = 5.0f;
                Text_Time.text = m_TimeSelected.ToString();
            }
            if (Slider_Time.value == 3)
            {
                m_TimeSelected = 10.0f;
                Text_Time.text = m_TimeSelected.ToString();
            }
            if (Slider_Time.value == 4)
            {
                m_TimeSelected = 15.0f;
                Text_Time.text = m_TimeSelected.ToString();
            }
            if (Slider_Time.value == 5)
            {
                m_TimeSelected = 30.0f;
                Text_Time.text = m_TimeSelected.ToString();
            }
            if (Slider_Time.value == 6)
            {
                m_TimeSelected = 60.0f;
                Text_Time.text = m_TimeSelected.ToString();
            }
            Text_Time.text = Text_Time.text + "s";
        }
    }

    void ButtonClicked(int ButtonNum)
    {
        if (ButtonNum == 0)
        {
            m_NumberOfDigits++;
            Text_NumDigits.text = m_NumberOfDigits.ToString();
        }
        else if (ButtonNum == 1)
        {
            m_NumberOfDigits--;
            Text_NumDigits.text = m_NumberOfDigits.ToString();
        }
        else if (ButtonNum == 2)
        {
            if (m_Addition == true)
                m_Addition = false;
            else
                m_Addition = true;
        }
        else if (ButtonNum == 3)
        {
            if (m_Subtraction == true)
                m_Subtraction = false;
            else
                m_Subtraction = true;
        }
        else if (ButtonNum == 4)
        {
            if (m_Multiplication == true)
                m_Multiplication = false;
            else
                m_Multiplication = true;
        }
        else if (ButtonNum == 5)
        {
            if (m_Division == true)
                m_Division = false;
            else
                m_Division = true;
        }
        else if (ButtonNum == 6)
        {
            m_ControlScheme++;
        }
        else if (ButtonNum == 7)
        {
            m_ControlScheme--;
        }
        else if (ButtonNum == 8)
        {
            if (m_TimeAttack == true)
                m_TimeAttack = false;
            else
                m_TimeAttack = true;
        }
        else if (ButtonNum == 9)
        {
            if (m_AdAttack == true)
                m_AdAttack = false;
            else
                m_AdAttack = true;
        }
    }


    public int GetNumberOfDigits()
    {
        return m_NumberOfDigits;
    }

    public bool GetOperatorAddition()
    {
        return m_Addition;
    }
    public bool GetOperatorSubttraction()
    {
        return m_Subtraction;
    }
    public bool GetOperatorMultiplication()
    {
        return m_Multiplication;
    }
    public bool GetOperatorDivision()
    {
        return m_Division;
    }
    public int GetControlScheme()
    {
        return m_ControlScheme;
    }
}

//if (Input.touchCount == 1) // user is touching the screen with a single touch
//{
//    Touch touch = Input.GetTouch(0); // get the touch
//    if (touch.phase == TouchPhase.Began) //check for the first touch
//    {
//        fp = touch.position;
//        lp = touch.position;
//    }
//    else if (touch.phase == TouchPhase.Moved) // update the last position based on where they moved
//    {
//        lp = touch.position;
//    }
//    else if (touch.phase == TouchPhase.Ended) //check if the finger is removed from the screen
//    {
//        lp = touch.position;  //last touch position. Ommitted if you use list

//        //Check if drag distance is greater than 20% of the screen height
//        if (Mathf.Abs(lp.x - fp.x) > m_DragDistance || Mathf.Abs(lp.y - fp.y) > m_DragDistance)
//        {//It's a drag
//         //check if the drag is vertical or horizontal
//            if (Mathf.Abs(lp.x - fp.x) > Mathf.Abs(lp.y - fp.y))
//            {   //If the horizontal movement is greater than the vertical movement...
//                if ((lp.x > fp.x))  //If the movement was to the right)
//                {   //Right swipe
//                    Debug.Log("Right Swipe");
//                }
//                else
//                {   //Left swipe
//                    Debug.Log("Left Swipe");
//                }
//            }
//            else
//            {   //the vertical movement is greater than the horizontal movement
//                if (lp.y > fp.y)  //If the movement was up
//                {   //Up swipe
//                    Debug.Log("Up Swipe");
//                }
//                else
//                {   //Down swipe
//                    Debug.Log("Down Swipe");
//                }
//            }
//        }
//        else
//        {   //It's a tap as the drag distance is less than 20% of the screen height
//            Debug.Log("Tap");
//        }
//    }
//}
