﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ProgressBar : MonoBehaviour
{
    public Slider m_Slider;

    public Image Image_Fill;
    public Image Image_BackGround;

    //public float m_MaxValue;
    //public float m_CurrentValue;
    //public float m_MinValue;


    // Start is called before the first frame update
    void Start()
    {
        //m_Slider.maxValue = m_MaxValue;
        //m_Slider.value = m_CurrentValue;
        //m_Slider.minValue = m_MinValue;

        m_Slider = this.GetComponent<Slider>();

       // Image_Fill = this.GetComponent<Image>();
       // Image_BackGround = this.GetComponent<Image>();
    }

    // Update is called once per frame
    void Update()
    {

    }

    public void SetValues(float MaxVal, float CurrentVal, float MinVal)
    {
        m_Slider.maxValue = MaxVal;
        m_Slider.value = CurrentVal;
        m_Slider.minValue = MinVal;
    }

    public void SetCurrentValue(float CurrentVal)
    {
        m_Slider.value = CurrentVal;
    }

    public void SetMaxValue(float MaxVal)
    {
        m_Slider.maxValue = MaxVal;
    }

    public void SetEnabled(bool Enabled)
    {
        if(Enabled == true)
        {
            m_Slider.enabled = true;
            Image_Fill.enabled = true;
            Image_BackGround.enabled = true;
        }
        else
        {
            m_Slider.enabled = false;
            Image_Fill.enabled = false;
            Image_BackGround.enabled = false;
        }
    }
}
