﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class PlayerData
{
    public int Num_Of_Questions_Answered;
    public int Num_Of_Questions_Correct;
    public int Num_Of_Questions_InCorrect;

    public int Control_Scheme;


    public PlayerData()
    {

    }
}
