﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class KeyPad : MonoBehaviour
{
    // Member Vars
    int m_NumberOfDigits;
    int m_NumberOfOperators;

    public GameManager m_GameManager;

    public bool Addition;
    public bool Subtraction;
    public bool Multiplication;
    public bool Division;
    public bool Modulus;

    bool b_KeySetup;
    bool b_AltKeySetup;
    bool b_AdAttack;
    bool b_TimeAttack;

    public int m_FirstNumber;
    public int m_SecondNumber;
    public int m_Answer;
    public int m_PlayerAnswer;
    public int m_ControlScheme;

    public float m_TimeSelected;

    public Operator m_Operator;

    // Text
    Text Text_Left;
    Text Text_Right;
    Text Text_Operator;
    Text Text_Answer;
    Text Text_FirstNumber;
    Text Text_SecondNumber;
    Text Text_TimeText;

    public Canvas Canvas_KeyPad;
    public Canvas Canvas_Alt_KeyPad;

    public ProgressBar m_TimeBar;

    // KeyPad Buttons
    public Button Key_1;
    public Button Key_2;
    public Button Key_3;
    public Button Key_4;
    public Button Key_5;
    public Button Key_6;
    public Button Key_7;
    public Button Key_8;
    public Button Key_9;
    public Button Key_0;
    public Button Key_Delete;
    public Button Key_Menu;

    public Timer Timer_TimeAttack;

    // public bool[] m_Operations; // 1: Addition, 2: Subtraction, 3: Muliplecation, 4; Division

    public enum Operator
    {
        Addition,
        Subtraction,
        Multiplication,
        Division
    }


    //EventSystem m_EventSystem = EventSystem.current;

    // Use this for initialization
    void Start()
    {
        m_ControlScheme = 0;
        m_Answer = 0;
        m_PlayerAnswer = 0;

        //m_EventSystem = EventSystem.current;

        Addition = true;
        Subtraction = false;
        Multiplication = false;
        Division = false;
        Modulus = false;
        b_AdAttack = false;
        b_TimeAttack = false;

        b_KeySetup = false;
        b_AltKeySetup = false;

        m_TimeBar.SetEnabled(false);

        Text_Answer = GameObject.Find("Answer Number").GetComponent<Text>();
        Text_FirstNumber = GameObject.Find("First Number").GetComponent<Text>();
        Text_SecondNumber = GameObject.Find("Second Number").GetComponent<Text>();
        Text_Operator = GameObject.Find("Operator").GetComponent<Text>();
        Text_TimeText = GameObject.Find("TimeText2").GetComponent<Text>();

        //GetKeyPadObjects();
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown("space"))
        {
            GenerateQuestion();
        }

        // If the player gets the answer right or the player awnsers the question in the negative correctly
        if(m_PlayerAnswer == m_Answer && m_GameManager.m_InGame == true || -m_PlayerAnswer == m_Answer && m_GameManager.m_InGame == true)
        {
            GenerateQuestion();
            Text_Answer.text = "";

            // Save Player Data
            m_GameManager.m_PlayerData.Num_Of_Questions_Answered++;
        }

        if(b_TimeAttack == true)
        {
            // Set the value of the time bar
            m_TimeBar.SetCurrentValue((Timer_TimeAttack.GetTimeLeft() / m_TimeSelected) * 100);


            // If the player took too long
            if (Timer_TimeAttack.IsTimerFinished() == true)
            {
                GenerateQuestion();
            }
        }
    }

    void GetKeyPadObjects()
    {
        //// Remove Listeners first
        //Key_1.onClick.RemoveListener(() => ButtonClicked(1));
        //Key_2.onClick.RemoveListener(() => ButtonClicked(2));
        //Key_3.onClick.RemoveListener(() => ButtonClicked(3));
        //Key_4.onClick.RemoveListener(() => ButtonClicked(4));
        //Key_5.onClick.RemoveListener(() => ButtonClicked(5));
        //Key_6.onClick.RemoveListener(() => ButtonClicked(6));
        //Key_7.onClick.RemoveListener(() => ButtonClicked(7));
        //Key_8.onClick.RemoveListener(() => ButtonClicked(8));
        //Key_9.onClick.RemoveListener(() => ButtonClicked(9));
        //Key_0.onClick.RemoveListener(() => ButtonClicked(0));
        //Key_Delete.onClick.RemoveListener(() => ButtonClicked(11));
        //Key_Menu.onClick.RemoveListener(() => ButtonClicked(12));

        //Canvas_KeyPad.enabled = false;
        //Canvas_Alt_KeyPad.enabled = false;

        // Find Objects for buttons
        if (m_ControlScheme == 0)
        {
            //Canvas_KeyPad.enabled = true;

            Key_1 = GameObject.Find("aButton 1").GetComponent<Button>();
            Key_2 = GameObject.Find("aButton 2").GetComponent<Button>();
            Key_3 = GameObject.Find("aButton 3").GetComponent<Button>();
            Key_4 = GameObject.Find("aButton 4").GetComponent<Button>();
            Key_5 = GameObject.Find("aButton 5").GetComponent<Button>();
            Key_6 = GameObject.Find("aButton 6").GetComponent<Button>();
            Key_7 = GameObject.Find("aButton 7").GetComponent<Button>();
            Key_8 = GameObject.Find("aButton 8").GetComponent<Button>();
            Key_9 = GameObject.Find("aButton 9").GetComponent<Button>();
            Key_0 = GameObject.Find("aButton 0").GetComponent<Button>();
            Key_Delete = GameObject.Find("aButton X").GetComponent<Button>();
            Key_Menu = GameObject.Find("aButton M").GetComponent<Button>();

            if (b_KeySetup == false)
            {
                b_KeySetup = true;
                Key_1.onClick.AddListener(() => ButtonClicked(1));
                Key_2.onClick.AddListener(() => ButtonClicked(2));
                Key_3.onClick.AddListener(() => ButtonClicked(3));
                Key_4.onClick.AddListener(() => ButtonClicked(4));
                Key_5.onClick.AddListener(() => ButtonClicked(5));
                Key_6.onClick.AddListener(() => ButtonClicked(6));
                Key_7.onClick.AddListener(() => ButtonClicked(7));
                Key_8.onClick.AddListener(() => ButtonClicked(8));
                Key_9.onClick.AddListener(() => ButtonClicked(9));
                Key_0.onClick.AddListener(() => ButtonClicked(0));
                Key_Delete.onClick.AddListener(() => ButtonClicked(11));
                Key_Menu.onClick.AddListener(() => ButtonClicked(12));
            }
        }

        if(m_ControlScheme == 1)
        {
            //Canvas_Alt_KeyPad.enabled = true;

            Key_1 = GameObject.Find("bButton 1").GetComponent<Button>();
            Key_2 = GameObject.Find("bButton 2").GetComponent<Button>();
            Key_3 = GameObject.Find("bButton 3").GetComponent<Button>();
            Key_4 = GameObject.Find("bButton 4").GetComponent<Button>();
            Key_5 = GameObject.Find("bButton 5").GetComponent<Button>();
            Key_6 = GameObject.Find("bButton 6").GetComponent<Button>();
            Key_7 = GameObject.Find("bButton 7").GetComponent<Button>();
            Key_8 = GameObject.Find("bButton 8").GetComponent<Button>();
            Key_9 = GameObject.Find("bButton 9").GetComponent<Button>();
            Key_0 = GameObject.Find("bButton 0").GetComponent<Button>();
            Key_Delete = GameObject.Find("bButton X").GetComponent<Button>();
            Key_Menu = GameObject.Find("bButton M").GetComponent<Button>();

            if (b_AltKeySetup == false)
            {
                b_AltKeySetup = true;
                Key_1.onClick.AddListener(() => ButtonClicked(21));
                Key_2.onClick.AddListener(() => ButtonClicked(22));
                Key_3.onClick.AddListener(() => ButtonClicked(23));
                Key_4.onClick.AddListener(() => ButtonClicked(24));
                Key_5.onClick.AddListener(() => ButtonClicked(25));
                Key_6.onClick.AddListener(() => ButtonClicked(26));
                Key_7.onClick.AddListener(() => ButtonClicked(27));
                Key_8.onClick.AddListener(() => ButtonClicked(28));
                Key_9.onClick.AddListener(() => ButtonClicked(29));
                Key_0.onClick.AddListener(() => ButtonClicked(20));
                Key_Delete.onClick.AddListener(() => ButtonClicked(31));
                Key_Menu.onClick.AddListener(() => ButtonClicked(32));
            }
        }    
    }


    public void ButtonClicked(int ButtonNum)
    {
        if ((ButtonNum >= 0 && ButtonNum <= 9))
        {
            Text_Answer.text = Text_Answer.text.ToString() + ButtonNum;
            m_PlayerAnswer = int.Parse(Text_Answer.text);
        }

        if (ButtonNum >= 20 && ButtonNum <= 29)
        {
            Text_Answer.text = Text_Answer.text.ToString() + (ButtonNum - 20);
            m_PlayerAnswer = int.Parse(Text_Answer.text);
        }

            if (ButtonNum == 11 || ButtonNum == 31)
        {
            Text_Answer.text = "";
            m_PlayerAnswer = 0;
        }

        if (ButtonNum == 12 || ButtonNum == 32)
        {
            m_GameManager.GoToScreen_Options();
        }

    }

    public void SetNumberOfDigits(int num)
    {
        m_NumberOfDigits = num;
    }

    /// <summary>
    /// / Set up the operators
    /// </summary>
    public void SetOperators(bool add, bool sub, bool multi, bool div)
    {
        Addition = add;
        Subtraction = sub;
        Multiplication = multi;
        Division = div;

        // Sets the number of operators for the game
        m_NumberOfOperators = 0;

        if (Addition == true)
            m_NumberOfOperators++;
        if (Subtraction == true)
            m_NumberOfOperators++;
        if (Multiplication == true)
            m_NumberOfOperators++;
        if (Division == true)
            m_NumberOfOperators++;

        GenerateQuestion();
    }

    /// <summary>
    ///  Set up the control Scheme
    /// </summary>
    public void SetControlScheme(int Scheme)
    {
        m_ControlScheme = Scheme;

        GetKeyPadObjects();
    }

    /// <summary>
    ///  Generate a question based on the operators selected
    /// </summary>
    void GenerateQuestion()
    {
        // Determine which operation will be asked      /// FIND A BETTER WAY THIS IS HORRIBLE
        // Ghetto while loop
        for(int i = 0; i < 100; i++)
        {
            int ran = Random.Range(0, 4);

            if (ran == 0)
            {
                if(Addition == true)
                {
                    m_Operator = Operator.Addition;
                    i = 400;
                }
            }
            else if (ran == 1)
            {
                if (Subtraction == true)
                {
                    m_Operator = Operator.Subtraction;
                    i = 400;
                }
            }
            else if (ran == 2)
            {
                if (Multiplication == true)
                {
                    m_Operator = Operator.Multiplication;
                    i = 400;
                }
            }
            else if (ran == 3)
            {
                if (Division == true)
                {
                    m_Operator = Operator.Division;
                    i = 400;
                }
            }
        } 


        // Determine the digits in the question

        // Get the even numbers
        if(m_NumberOfDigits % 2 == 0)
        {       
            int ran = Random.Range(0, 10 * (m_NumberOfDigits /2));
            m_FirstNumber = ran;
            ran = Random.Range(0, 10 * (m_NumberOfDigits / 2));
            m_SecondNumber = ran;
        }
        else
        {
            int ran = Random.Range(0, 10 * ((m_NumberOfDigits - 1) / 2));
            m_FirstNumber = ran;
            ran = Random.Range(0, 10 * (((m_NumberOfDigits - 1) / 2) + 1));
            m_SecondNumber = ran;
        }

        // Calculate the answer
        if(m_Operator == Operator.Addition)
        {
            m_Answer = m_FirstNumber + m_SecondNumber;
            Text_Operator.text = "+";
        }
        else if(m_Operator == Operator.Subtraction)
        {
            m_Answer = m_FirstNumber - m_SecondNumber;
            Text_Operator.text = "-";
        }
        else if (m_Operator == Operator.Multiplication)
        {
            m_Answer = m_FirstNumber * m_SecondNumber;
            Text_Operator.text = "X";
        }
        else if (m_Operator == Operator.Division)
        {
            m_Answer = m_FirstNumber / m_SecondNumber;
            Text_Operator.text = "/";
        }

        // Set the text
        Text_FirstNumber.text =  m_FirstNumber.ToString();
        Text_SecondNumber.text = m_SecondNumber.ToString();

        // Start the Timer (if its on)
            SetupTimer();
    }

    void SetupTimer()
    {
        if(b_TimeAttack == true)
        {
            m_TimeBar.SetValues(100, 0, 0);

            Timer_TimeAttack.ResetTimer(m_TimeSelected);
            Timer_TimeAttack.StartTimer();
            Text_TimeText.text = "Time:";
        }
        else
        {
            Text_TimeText.text = "";
        }
    }

    /// <summary>
    ///  Set up the Timebar and Ad Attack
    /// </summary>
    public void SetGameOptions(bool Ad, float time)
    {
        b_AdAttack = Ad;
        m_TimeSelected = time;

        if (m_TimeSelected > 0)
        {
            b_TimeAttack = true;

            m_TimeBar.SetEnabled(true);
        }
        else if (m_TimeSelected == 0)
        {
            b_TimeAttack = false;
            m_TimeBar.SetEnabled(false);
        }
    }

    void PlayerLost(bool FromTimer)
    {

    }

    public void ToggleCanvases(bool toggle)
    {
        if(toggle == true)
        {

        }
       
    }
}
