﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

public static class SaveSystem
{
   public static void Save(PlayerData playerData)
    {
        // Create the formatter and path
        BinaryFormatter formatter = new BinaryFormatter();
        string path = Application.persistentDataPath + "/PlayerData.dta";
        FileStream stream = new FileStream(path, FileMode.Create);

        // Get the player data
        PlayerData data = playerData;

        formatter.Serialize(stream, data);
        // Always close the stream
        stream.Close();
    }

    public static PlayerData Load()
    {
        string path = Application.persistentDataPath + "/PlayerData.dta";
        if(File.Exists(path))
        {
            BinaryFormatter formatter = new BinaryFormatter();
            FileStream stream = new FileStream(path, FileMode.Open);

            PlayerData data = formatter.Deserialize(stream) as PlayerData;
            stream.Close();

            return data;
        }
        else
        {
            Debug.Log("Save file not found. Path: " + path);
            return null;
        }
    }
}
