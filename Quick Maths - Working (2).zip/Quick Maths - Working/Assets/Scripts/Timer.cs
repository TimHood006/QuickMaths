﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Timer : MonoBehaviour
{
    float m_Duration;
    float m_TimeUntilFinish;

    bool m_IsRunning;
    bool m_IsTimerDone;

    // Start is called before the first frame update
    void Start()
    {
        m_Duration = 0;
        m_TimeUntilFinish = 0;

        m_IsRunning = false;
        m_IsTimerDone = false;
    }

    void Start(float Duration)
    {
        m_Duration = Duration;
        m_TimeUntilFinish = 0;

        m_IsRunning = false;
        m_IsTimerDone = false;
    }

    // Update is called once per frame
    void Update()
    {
        if(m_IsRunning == true)
        {
            m_TimeUntilFinish -= Time.deltaTime;

            if(m_TimeUntilFinish < 0)
            {
                m_IsRunning = false;
                m_IsTimerDone = true;
            }
        }
    }

    public void StartTimer()
    {
        m_TimeUntilFinish = m_Duration;
        m_IsRunning = true;
        m_IsTimerDone = false;
    }

    public void ResetTimer(float Duration)
    {
        m_Duration = Duration;
        m_TimeUntilFinish = 0;

        m_IsRunning = false;
        m_IsTimerDone = false;
    }

    public bool IsTimerFinished()
    { return m_IsTimerDone; }

    public void SetDuration(float Duration)
    {  m_Duration = Duration;  }

    public float GetDuration()
    { return m_Duration; }

    public float GetTimeLeft()
    { return m_TimeUntilFinish; }

    public bool CheckIfTimerIsRunning()
    { return m_IsRunning; }
}
