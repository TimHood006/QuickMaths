﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class GameManager : MonoBehaviour
{

    public Canvas Canvas_MainMenu;
    public Canvas Canvas_Game;
    public Canvas Canvas_Options;
    public Canvas Canvas_Controls;
    public Canvas Canvas_Stats;
    public Canvas Canvas_GameMenu;
    public Canvas Canvas_Keypad;
    public Canvas Canvas_AltKeypad;

    public Button Button_MenuPlay;
    public Button Button_GameStart;
    public Button Button_ControlsMenu;
    public Button Button_OptionsMenu;
    public Button Button_StatsMenu;

    public PlayerData m_PlayerData;


    public string t_GameState;

    public bool m_InGame;

    GameState m_GameState;

    KeyPad m_KeyPad;
    GameMenu m_GameMenu;

    enum GameState
    {
        Menu,
        Options,
        Stats,
        Controls,
        Game
    }


    // Use this for initialization
    void Start()
    {
        m_GameState = 0;

        m_InGame = false;

        GetGameObjects();

        // Disable unsed canvases
        Canvas_MainMenu.enabled = true;
        Canvas_Game.enabled = false;
        Canvas_Options.enabled = false;
        Canvas_Controls.enabled = false;
        Canvas_Stats.enabled = false;
        Canvas_GameMenu.enabled = false;

        if(SaveSystem.Load() == null)
        {
            Debug.Log("Creating new SaveFile.");
            SaveSystem.Save(m_PlayerData);
        }

        m_PlayerData = SaveSystem.Load();             
    }

    // Update is called once per frame
    void Update()
    {
        // Set the game state everyframe
        t_GameState = m_GameState.ToString();


        if (m_GameState == GameState.Menu)
        {
            Canvas_MainMenu.enabled = true;
            Canvas_Game.enabled = false;
            Canvas_Options.enabled = false;
            Canvas_Controls.enabled = false;
            Canvas_Stats.enabled = false;
            Canvas_GameMenu.enabled = false;

            Canvas_Keypad.enabled = false;
            Canvas_AltKeypad.enabled = false;
            m_InGame = false;
        }

        if(m_GameState == GameState.Options)
        {
            Canvas_MainMenu.enabled = false;
            Canvas_Game.enabled = false;
            Canvas_Options.enabled = true;
            Canvas_Controls.enabled = false;
            Canvas_Stats.enabled = false;
            Canvas_GameMenu.enabled = true;

            // Change button Color (Orange)
            Button_OptionsMenu.GetComponent<Image>().color = new Color32(225, 170, 107, 100);
            Button_ControlsMenu.GetComponent<Image>().color = new Color32(225, 225, 225, 100);
            Button_StatsMenu.GetComponent<Image>().color = new Color32(225, 225, 225, 100);

            Canvas_Keypad.enabled = false;
            Canvas_AltKeypad.enabled = false;
            m_InGame = false;
            SaveSystem.Save(m_PlayerData);
        }

        if (m_GameState == GameState.Game)
        {
            Canvas_MainMenu.enabled = false;
            Canvas_Game.enabled = true;
            Canvas_Options.enabled = false;
            Canvas_Controls.enabled = false;
            Canvas_Stats.enabled = false;
            Canvas_GameMenu.enabled = false;

            if(m_InGame == false)
            {
                m_InGame = true;              

                if(m_GameMenu.GetControlScheme() == 0)
                {
                    Canvas_Keypad.enabled = true;
                }
                else if (m_GameMenu.GetControlScheme() == 1)
                {
                    Canvas_AltKeypad.enabled = true;
                }
            }
        }

        if (m_GameState == GameState.Controls)
        {
            Canvas_MainMenu.enabled = false;
            Canvas_Game.enabled = false;
            Canvas_Options.enabled = false;
            Canvas_Controls.enabled = true;
            Canvas_Stats.enabled = false;
            Canvas_GameMenu.enabled = true;

            Canvas_Keypad.enabled = false;
            Canvas_AltKeypad.enabled = false;
            m_InGame = false;

            // Change button Color (Orange)
            Button_ControlsMenu.GetComponent<Image>().color = new Color32(225, 170, 107, 100);
            Button_OptionsMenu.GetComponent<Image>().color = new Color32(225, 225, 225, 100);
            Button_StatsMenu.GetComponent<Image>().color = new Color32(225, 225, 225, 100);
        }

        if (m_GameState == GameState.Stats)
        {
            Canvas_MainMenu.enabled = false;
            Canvas_Game.enabled = false;
            Canvas_Options.enabled = false;
            Canvas_Controls.enabled = false;
            Canvas_Stats.enabled = true;
            Canvas_GameMenu.enabled = true;

            Canvas_Keypad.enabled = false;
            Canvas_AltKeypad.enabled = false;
            m_InGame = false;

            // Change button Color (Orange)
            Button_StatsMenu.GetComponent<Image>().color = new Color32(225, 170, 107, 100);
            Button_ControlsMenu.GetComponent<Image>().color = new Color32(225, 225, 225, 100);
            Button_OptionsMenu.GetComponent<Image>().color = new Color32(225, 225, 225, 100);
        }


    }

    void GetGameObjects()   // Gets the objects in the scene
    {
        //Canvas_MainMenu = GameObject.Find("Main Menu").GetComponent<Canvas>();
        //Canvas_Game = GameObject.Find("Game").GetComponent<Canvas>();
        //Canvas_Options = GameObject.Find("Options").GetComponent<Canvas>();
        // Canvas_Controls = GameObject.Find("Controls Menu").GetComponent<Canvas>();
        // Canvas_Stats = GameObject.Find("Main Menu").GetComponent<Canvas>();

        // Button_PlayStart = GameObject.Find("Play Button Whole Screen").GetComponent<Button>();
        // Button_OptionsStart = GameObject.Find("Start Button").GetComponent<Button>();


        m_KeyPad = Canvas_Game.GetComponent<KeyPad>();
        m_GameMenu = Canvas_GameMenu.GetComponent<GameMenu>();

        Canvas_MainMenu.enabled = true;
        Canvas_Game.enabled = true;
        Canvas_Options.enabled = true;
        Canvas_Controls.enabled = true;
        Canvas_Stats.enabled = true;
        Canvas_GameMenu.enabled = true;

        Button_MenuPlay.onClick.AddListener(() => ButtonClicked(1));
        Button_GameStart.onClick.AddListener(() => ButtonClicked(2));
        Button_OptionsMenu.onClick.AddListener(() => ButtonClicked(3));
        Button_ControlsMenu.onClick.AddListener(() => ButtonClicked(4));
        Button_StatsMenu.onClick.AddListener(() => ButtonClicked(5));
    }

    public void ButtonClicked(int ButtonNum)
    {
        if(ButtonNum == 1)
        {
            // Go to options
            m_GameState = GameState.Options;
        }
        else if (ButtonNum == 2)
        {
            // Start the game
            m_GameState = GameState.Game;

            StartGame();
        }
        if (ButtonNum == 3)
        {
            // Go to options
            m_GameState = GameState.Options;
        }
        if (ButtonNum == 4)
        {
            // Go to controls
            m_GameState = GameState.Controls;
        }
        if (ButtonNum == 5)
        {
            // Go to stats
            m_GameState = GameState.Stats;
        }
    }


    public void GoToScreen_Options()
    {
        //Canvas_MainMenu.enabled = false;
        //Canvas_Game.enabled = false;
        //Canvas_Options.enabled = true;
        //Canvas_Controls.enabled = false;
        //Canvas_Stats.enabled = false;

        m_GameState = GameState.Options;
    }

    void StartGame()
    {
        m_KeyPad.SetNumberOfDigits(m_GameMenu.GetNumberOfDigits());

        m_KeyPad.SetControlScheme(m_GameMenu.GetControlScheme());

        m_KeyPad.SetGameOptions(m_GameMenu.GetAdAttack(), m_GameMenu.GetTime());

        m_KeyPad.SetOperators(m_GameMenu.GetOperatorAddition(), m_GameMenu.GetOperatorSubttraction(), m_GameMenu.GetOperatorMultiplication(), m_GameMenu.GetOperatorDivision());
    }

    public void GoToScreen_Controls()
    {
        //Canvas_MainMenu.enabled = false;
        //Canvas_Game.enabled = false;
        //Canvas_Options.enabled = false;
        //Canvas_Controls.enabled = true;
        //Canvas_Stats.enabled = false;
    }

    public void GoToScreen_Stats()
    {
        //Canvas_MainMenu.enabled = false;
        //Canvas_Game.enabled = false;
        //Canvas_Options.enabled = false;
        //Canvas_Controls.enabled = false;
        //Canvas_Stats.enabled = true;
    }

    public void GoToScreen_Game()
    {
        //Canvas_MainMenu.enabled = false;
        //Canvas_Game.enabled = true;
        //Canvas_Options.enabled = false;
        //Canvas_Controls.enabled = false;
        //Canvas_Stats.enabled = false;
    }
}